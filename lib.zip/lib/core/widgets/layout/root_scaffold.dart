import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:voicesewa_client/core/constants/app_constants.dart';
import 'package:voicesewa_client/app/routes.dart';
import 'package:voicesewa_client/core/widgets/navigation/bottom_navbar_widget.dart';
import 'package:voicesewa_client/core/widgets/layout/appbar_widget.dart';
import 'package:voicesewa_client/core/providers/navbar_page_provider.dart';

import '../../extensions/context_extensions.dart';

class RootScaffold extends ConsumerWidget {
  const RootScaffold({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentTab = ref.watch(navTabProvider);
    final routeName = AppConstants.pages(context)[currentTab]![2] as String;

    /// Look up the WidgetBuilder from AppRoutes
    final builder = AppRoutes.routes[routeName];

    if (builder == null) {
      // Fallback in case the route is missing
      return const Scaffold(
        body: Center(child: Text('Page not found')),
      );
    }

    return Scaffold(
      appBar: AppBarWidget(title: context.loc.appName),
      bottomNavigationBar: const BottomNavBar(),
      body: SafeArea(
        child: builder(context), 
      ),
    );
  }
}
