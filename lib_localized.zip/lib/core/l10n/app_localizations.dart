import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'app_localizations_en.dart';
import 'app_localizations_hi.dart';
import 'app_localizations_gu.dart';
import 'app_localizations_mr.dart';

// ignore_for_file: type=lint

abstract class AppLocalizations {
  AppLocalizations(this.locale);
  final String locale;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = [
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
  ];

  static const List<Locale> supportedLocales = [
    Locale('en'),
    Locale('hi'),
    Locale('gu'),
    Locale('mr'),
  ];

  String get appName;
  String get welcomeMessage;
  String get loginPrompt;
  String get signUpPrompt;
  String get errorMessage;
  String get loadingMessage;
  String get logoutConfirmation;
  String get authTitle;
  String get homeTitle;
  String get searchTitle;
  String get voiceBotTitle;
  String get historyTitle;
  String get profileTitle;
  String get bookCTA;
  String get activeBookingsCTA;
  String get offersCTA;
  String get helpCTA;
  String get chatTitle;
  String get settingsTitle;
  String get termsAndConditions;
  String get privacyPolicy;
  String get contactUs;
  String get feedbackPrompt;
  String get updateAvailable;
  String get noInternetConnection;
  String get selectLanguage;
  String get trackRecentRequests;
  String get worker;
  String get eTA;
  String get quickBookServices;
  String get bookAgain;
  String get myRequests;
  String get offers;
  String get helpAndSupport;
  String get distance;
  String get price;
  String get rating;
  String get yrsExperience;
  String get available;
  String get unavailable;
  String get skills;
  String get bookNow;
  String get playVoiceIntro;
  String get oldestFirst;
  String get newestFirst;
  String get amount;
  String get noJobsMatchTheSelectedFilters;
  String get activeJobs;
  String get completedJobs;
  String get all;
  String get scheduled;
  String get inProgress;
  String get completed;
  String get cancelled;
  String get filter;
  String get sort;
  String get yourRating;
  String get invoice;
  String get details;
  String get date;
  String get status;
  String get five;
  String get userPreferences;
  String get language;
  String get selectYourPreferredLanguage;
  String get notifications;
  String get manageSavedAddresses;
  String get dataUsageAndOfflineCache;
  String get configureDownloadAndCacheLimits;
  String get appSettings;
  String get darkMode;
  String get logout;
  String get deleteAccount;
  String get account;
  String get supportAndHelp;
  String get speakWhatIsTheProblem;
  String get quickAssistance;
  String get paymentIssue;
  String get workerNotArrived;
  String get fAQs;
  String get chatWithSupport;
  String get chatFunctionalityComingSoon;
  String get oK;
  String get cancelJob;
  String get listening;
  String get voiceRecognition;
  String get speakNow;
  String get startSpeaking;
  String get noTextRecognized;
  String get loadingProfile;
  String get locationCapturedAddressAutofilled;
  String get houseFlatNoStreetName;
  String get addressLine2;
  String get apartmentSuiteBuildingOptional;
  String get landmark;
  String get nearbyLandmarkOptional;
  String get cityName;
  String get sixDigits;
  String get noJobsMatchTheSelectedFilters2;
  String get noRecentRequests;
  String get retry;
  String get jobDetails;
  String get jobNotFound;
  String get thankYouForYourFeedback;
  String get areYouSureYouWantToCancelThisJob;
  String get no;
  String get jobCancelled;
  String get yesCancel;
  String get rescheduleJob;
  String get selectNewDate;
  String get cancel;
  String get jobRescheduled;
  String get confirm;
  String get addressSavedForFutureUse;
  String get pleaseSelectAService;
  String get pleaseSelectWhenYouWantTheJobDone;
  String get pleaseFillRequiredAddressFields;
  String get pleaseCaptureLocationForTheAddress;
  String get pleaseSelectAnAddress;
  String get createJobRequest;
  String get describeWhatYouNeedDone;
  String get selectAddress;
  String get oTPCopiedToClipboard;
  String get copyOTP;
  String get created;
  String get addFeedback;
  String get pleaseSelectAStarRating;
  String get writeACommentOptional;
  String get maybeLater;
  String get voiceAssistant;
  String get assistantIsResponding;
  String get tapTheMicToStartTalking;
  String get quotations;
  String get acceptQuotation;
  String get quotationAcceptedOTPGenerated;
  String get confirmAccept;
  String get rejectQuotation;
  String get reasonOptional;
  String get whyAreYouRejectingThis;
  String get quotationRejected;
  String get reject;
  String get callWorker;
  String get typeAMessage;
  String get estCost;
  String get estTime;
  String get rejectionReason;
  String get withdrawalReason;
  String get viewed;
  String get accepted;
  String get rejected;
  String get withdrawn;
  String get updated;
  String get accept;
  String get contactWorker;
  String get allServices;
  String get clearFilters;
  String get twoKm;
  String get fiveKm;
  String get nameAndPhoneAreRequired;
  String get profileCreatedSuccessfully;
  String get completeYourProfile;
  String get personalInformation;
  String get fullName;
  String get enterYourFullName;
  String get phoneNumber;
  String get tenDigitMobileNumber;
  String get serviceAddress;
  String get skipAddressAddLater;
  String get loginSuccessful;
  String get email;
  String get password;
  String get signIn;
  String get signUp;
  String get accountCreatedSuccessfully;
  String get username;
  String get confirmPassword;
  String get speak;
  String get comingSoon;
  String get comingSoon2;
  String get pageNotFound;
  String get langHindi;
  String get langMarathi;
  String get langGujarati;

}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      ['en', 'hi', 'gu', 'mr'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    switch (locale.languageCode) {
      case 'hi':
        return AppLocalizationsHi();
      case 'gu':
        return AppLocalizationsGu();
      case 'mr':
        return AppLocalizationsMr();
      default:
        return AppLocalizationsEn();
    }
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
